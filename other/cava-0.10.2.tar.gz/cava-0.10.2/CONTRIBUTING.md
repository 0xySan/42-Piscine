# How to contribute
Thank you for wanting to contribute to this project. In order to get the development of this project to run as smooth as possible, we will encourage all contributions to follw this simple process:

1. Before any pull request is submitted a github issue must be created for the task.
2. The new github task is to be opened for suggestions from other contributors.
3. A pull request is published.
4. Contributors code review pull request and approve/reject pull request.
5. Pull request either gets approved or rejected.
5. Github task is updated and everyone is notified.

# Coding conventions
* 4 spaces for indents
* curly braces on same line as if, while, for statements

Generally please try to keep the style consistent with the code as it is. 
