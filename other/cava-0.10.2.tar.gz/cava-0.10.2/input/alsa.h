// header file for alsa, part of cava.

#pragma once

void *input_alsa(void *data);
