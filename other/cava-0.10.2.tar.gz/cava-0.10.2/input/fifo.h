// header files for fifo, part of cava

#pragma once

void *input_fifo(void *data);
