// header file for jack, part of cava.

#pragma once

void *input_jack(void *data);
