// header file for oss, part of cava.

#pragma once

void *input_oss(void *data);
