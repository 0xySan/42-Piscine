// header file for pipewire, part of cava.

#pragma once

void *input_pipewire(void *data);