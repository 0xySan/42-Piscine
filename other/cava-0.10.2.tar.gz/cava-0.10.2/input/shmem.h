// header file for shmem, part of cava.

#pragma once

void *input_shmem(void *data);
