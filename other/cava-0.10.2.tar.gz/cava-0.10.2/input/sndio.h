// header file for sndio, part of cava.

#pragma once

void *input_sndio(void *data);
