// header files for winscap, part of cava

#ifdef __cplusplus
extern "C" {
#endif

#pragma once

void *input_winscap(void *data);

#pragma once
#ifdef __cplusplus
}
#endif
