#pragma once

int init_terminal_bcircle(int col, int bgcol);
void get_terminal_dim_bcircle(int *w, int *h);
int draw_terminal_bcircle(int virt, int height, int width, int f[]);
void cleanup_terminal_bcircle(void);
