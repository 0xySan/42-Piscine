### Basic information

<!-- all required -->

<!-- with version or distribution -->
* OS: 

<!-- with version -->
* Terminal emulator: 

<!-- with version, if you use; if not, remove this part -->
* Terminal multiplexer: 

<!-- paste the output -->
* `echo $TERM`: 

* Bash version: 

* pipes.sh version or commit hash: 

<!-- list anything else that would help -->

### Expected behavior



### Actual behavior

<!--
  * Consider upload a screenshot, if helpful.

  * Please put terminal output or code in fenced block, for examples:

    ```
    user $ echo $TERM
    xterm
    ```

    ```bash
    # some Bash code
    ```
-->

### Steps to reproduce the behavior


